#!/bin/sh

now=`date "+%Y%m%d%H%M%S"`
log_file="log_"$now".log"
echo $log_file

nohup ./sdchaind --load >./log/$log_file &

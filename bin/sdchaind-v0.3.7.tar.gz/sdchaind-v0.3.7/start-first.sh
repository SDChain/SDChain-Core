#!/bin/sh

now=`date "+%Y%m%d%H%M%S"`
mkdir log
log_file="log_"$now".log"
echo $log_file

nohup ./sdchaind >./log/$log_file &
